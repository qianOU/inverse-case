# -*- coding: utf-8 -*-
import scrapy
import re
import requests
from pyquery import PyQuery as pq
from dangdang.items import DangdangItem
class DandanSpider(scrapy.Spider):
    name = 'dandan'
    
